function imOut = myHistMatching(input, reference)

M = zeros(256,1,'uint8'); 
hist1 = imhist(input); 
hist2 = imhist(reference);
cdf1 = cumsum(hist1) / numel(input); 
cdf2 = cumsum(hist2) / numel(reference);


for i = 1 : 256
    [~,ind] = min(abs(cdf1(i) - cdf2));
    M(i) = ind-1;
end

imOut = M(double(input)+1);

% figure,stem(cdf1);
% figure,stem(hist1)
% figure,stem(cdf2);
% figure,stem(hist2);

figure,
subplot(1,3,1) ; imshow(imread('input.png'));
subplot(1,3,2); stem(hist1);
figure,
subplot(1,3,1) ; imshow(imread('reference.png'));
subplot(1,3,2); stem(hist2);

figure,
subplot(1,2,1) ; imshow(imOut);
subplot(1,2,2); stem(imhist(imOut));

end